/*
@file    main.c
@brief   main
@version 1.0
@date    2018-11-10
@author  Rudolph Riedel

@section History

1.0
- restart with SAMC21 and EVE 4.0

 */


#include "sam.h"

#include "EVE_commands.h"
#include "tft.h"


volatile uint8_t system_tick = 0;

void SysTick_Handler(void)
{
	system_tick = 42;
}


void init_clock(void)
{
	REG_NVMCTRL_CTRLB = NVMCTRL_CTRLB_RWS(2);	// Set the NVM Read Wait States to 2, Since the operating frequency will be 48 MHz

	REG_OSCCTRL_XOSCCTRL =  OSCCTRL_XOSCCTRL_STARTUP(6) |		// 1,953 ms
							OSCCTRL_XOSCCTRL_RUNSTDBY |
							OSCCTRL_XOSCCTRL_AMPGC |
							OSCCTRL_XOSCCTRL_GAIN(3) |
							OSCCTRL_XOSCCTRL_XTALEN |
							OSCCTRL_XOSCCTRL_ENABLE;

	while((REG_OSCCTRL_STATUS & OSCCTRL_STATUS_XOSCRDY) == 0);

	/* configure the PLL, source = XOSC, pre-scaler = 8, multiply by 24 -> 48MHz clock from 16MHz input */
	REG_OSCCTRL_DPLLCTRLB = OSCCTRL_DPLLCTRLB_DIV(3) | OSCCTRL_DPLLCTRLB_REFCLK(1); // setup PLL to use XOSC input
	REG_OSCCTRL_DPLLRATIO = OSCCTRL_DPLLRATIO_LDRFRAC(0x0) | OSCCTRL_DPLLRATIO_LDR(23);
	REG_OSCCTRL_DPLLCTRLA = OSCCTRL_DPLLCTRLA_RUNSTDBY | OSCCTRL_DPLLCTRLA_ENABLE;
	while((REG_OSCCTRL_DPLLSTATUS & OSCCTRL_DPLLSTATUS_CLKRDY) != 0); // wait for the pll to be ready

	REG_GCLK_GENCTRL0 = GCLK_GENCTRL_DIV(0) |
						GCLK_GENCTRL_RUNSTDBY |
						GCLK_GENCTRL_GENEN |
						//GCLK_GENCTRL_SRC_XOSC |
						GCLK_GENCTRL_SRC_DPLL96M |
						GCLK_GENCTRL_IDC ;

	while((REG_GCLK_SYNCBUSY & GCLK_SYNCBUSY_GENCTRL0) != 0);	// Wait for the synchronization between clock domain is complete
}


void init_io(void)
{
	REG_PORT_DIRSET0 = PORT_PA03; // PD_TFT
	REG_PORT_DIRCLR0 = PORT_PA04; // MISO
	REG_PORT_DIRSET0 = PORT_PA05; // CS_TFT
	REG_PORT_DIRSET0 = PORT_PA06; // MOSI
	REG_PORT_DIRSET0 = PORT_PA07; // SCK

	REG_PORT_OUTCLR0 = PORT_PA03; // PD_TFT
	REG_PORT_OUTSET0 = PORT_PA05; // CS_TFT
	REG_PORT_OUTCLR0 = PORT_PA06;
	REG_PORT_OUTCLR0 = PORT_PA07;

	PORT->Group[0].PINCFG[4].reg |= PORT_PINCFG_INEN;
}


void init_spi(void)
{
	// todo: clock-config, io-mux-config
	REG_SERCOM0_SPI_CTRLA = 0x00; // reset-dafault, disable SPI, also MSB first, CPOL = 0, CPHA = 0, SPI frame, PAD0 = MISO
	REG_SERCOM0_SPI_CTRLA |= SERCOM_SPI_CTRLA_MODE(3) | SERCOM_SPI_CTRLA_DOPO(1); // select SPI master mode, PAD2 = MOSI, PAD3 = SCK
	REG_SERCOM0_SPI_BAUD = 2; // 8MHZ clock from 48MHz core-clock

	REG_SERCOM0_SPI_CTRLB = SERCOM_SPI_CTRLB_RXEN; // receiver enabled, no hardware select, 8-bit
}


int main(void)
{
	init_clock();
	init_io();
	SysTick_Config(48000000 / 100); // configure and Enable Systick for 10 ms ticks

	TFT_init();

	while (1)
	{
		if(system_tick)
		{
			system_tick = 0;

			TFT_loop();
			num_profile_a++;
		}
	}
}
